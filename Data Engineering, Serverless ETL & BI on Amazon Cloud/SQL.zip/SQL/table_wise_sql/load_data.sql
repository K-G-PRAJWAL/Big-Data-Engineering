
LOAD DATA LOCAL INFILE '/your_local_system_path/table_name.csv' 
INTO TABLE table_name FIELDS TERMINATED BY ','
ENCLOSED BY '"' IGNORE 1 LINES;