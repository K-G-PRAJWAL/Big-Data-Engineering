select 
	*
from 
	ecommerce_db.sellers 