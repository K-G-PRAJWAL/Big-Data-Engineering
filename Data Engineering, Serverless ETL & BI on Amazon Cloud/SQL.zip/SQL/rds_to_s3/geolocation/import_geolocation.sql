select 
	*
from 
	ecommerce_db.geolocation 